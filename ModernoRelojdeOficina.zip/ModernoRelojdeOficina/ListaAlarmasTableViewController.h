//
//  ListaAlarmasTableViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 27/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EditAlarmTableViewController.h"
#import "sonidosViewController.h"
#import "EditAlarmTableViewController.h"
#import "Settings.h"
#import "insist.h"
#import <AudioToolbox/AudioToolbox.h>

@class EditAlarmTableViewController;
@protocol ajustesViewControllerDelegate;

@class SonidoViewController;
@interface ListaAlarmasTableViewController : UITableViewController<UITextViewDelegate,UINavigationControllerDelegate,
UIImagePickerControllerDelegate, NSURLConnectionDelegate>{
    id delegateAjuste;
    
    NSArray*sounds;
    NSArray*soundStrings;
    
    
    
    NSString*timeViewControllerNibName;
    UILabel *detailDescriptionLabel;
    
    
    IBOutlet UILabel *response;
    NSMutableData *_responseData;
    

    
}



@property (nonatomic, assign) int time;
@property (nonatomic, assign) BOOL vibrate;
@property (nonatomic, assign) float volume;
@property (nonatomic, assign) float soundIndex;

@property NSUserDefaults *userDefaults;;



@property (strong, nonatomic) EditAlarmTableViewController *detailViewController;


-(void)archive;
-(NSArray*)getSoundStrings;
-(NSArray*)getTimeStrings;
-(NSString*)snoozeStringForInt:(int)minutes;
-(NSURL*)urlForSound:(int)index;
-(NSString*)fileNameForSound:(int)index;

-(bool)on;

// hora 1
@property (strong, nonatomic) id detailItem;
@property (nonatomic, retain) IBOutlet UITableViewCell*Alarmaenabled1Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Alarmaenabled1CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*AlarmaenabledCell;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarma1;


@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaActivada;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaDesactivada;



// hora 2
@property (nonatomic, retain) IBOutlet UITableViewCell*Alarmaenabled2Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Alarmaenabled2CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*EnabledAmarla2Cell;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarma2;


@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaActivada2;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaDesactivada2;



// hora 3
@property (nonatomic, retain) IBOutlet UITableViewCell*Alarmaenabled3Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Alarmaenabled3CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*EnabledAmarla3Cell;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarma3;


@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaActivada3;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaDesactivada3;



// hora 4
@property (nonatomic, retain) IBOutlet UITableViewCell*Alarmaenabled4Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Alarmaenabled4CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*EnabledAmarla4Cell;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarma4;


@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaActivada4;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaDesactivada4;

// hora 5
@property (nonatomic, retain) IBOutlet UITableViewCell*Alarmaenabled5Cell;
@property (nonatomic, retain) IBOutlet UISwitch*Alarmaenabled5CellSwitch;
@property (nonatomic, retain) IBOutlet UITableViewCell*EnabledAmarla5Cell;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarma5;


@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaActivada5;
@property (nonatomic, retain) IBOutlet UILabel*lblHoraAlarmaDesactivada5;


- (void)sonidoViewController: (SonidoViewController *)controller
             didSelectSonido:(NSString *)sonido;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil timeViewControllerNibName:(NSString*)aName;

- (IBAction)Activarhora1:(id)sender;
- (IBAction)Activarhora2:(id)sender;
- (IBAction)Activarhora3:(id)sender;
- (IBAction)Activarhora4:(id)sender;
- (IBAction)Activarhora5:(id)sender;



@property (nonatomic, retain) id delegateAjuste;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;



@end

@protocol ajustesViewControllerDelegate

- (void) metodoAjuste;

@end
