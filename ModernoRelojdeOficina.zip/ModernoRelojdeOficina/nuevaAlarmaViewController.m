//
//  nuevaAlarmaViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 08/04/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "nuevaAlarmaViewController.h"
#import "Alarma.h"
#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"
#import "addAlarmaCell.h"

@interface nuevaAlarmaViewController ()
@end

@implementation nuevaAlarmaViewController
@synthesize PikerTime = _PikerTime;
@synthesize plusButton = _plusButton;
@synthesize minusButton = _minusButton;
@synthesize LblTime = _LblTime;
@synthesize enableSwich = _enableSwich;

@synthesize editingAlarma, datePicker, uiTableView, tituloVentana, celdaEstado, arrayAlarmas;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
         navigationItem=[self navigationItem];
        [navigationItem setTitle:tituloVentana];
        
        [navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelar)] animated:YES];
        [navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(guardar)] animated:YES];
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    
  
    sonidosVC=[[sonidosViewController alloc]init];
    
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
}

-(void)viewWillDisappear:(BOOL)animated
{
    [self preservarHora];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Metodos de la clase
-(void)preservarHora
{
    NSDate *dateBruto=[datePicker date];
    
    NSTimeInterval time=round([dateBruto timeIntervalSinceReferenceDate]/60.0)*60.0;
    NSDate *dateSinSegundos=[NSDate dateWithTimeIntervalSinceReferenceDate:time];
    
    
    NSLog(@"%@", [dateSinSegundos description]);
}
-(void)guardar
{
    if(arrayAlarmas)
    {
        UIAlertView *alerta=[[UIAlertView alloc]initWithTitle:NSLocalizedString(@"Error", @"ErrorCadenaVacia") message:NSLocalizedString(@"El campo titulo es obligatorio.", @"Titulo en blanco") delegate:self cancelButtonTitle:NSLocalizedString(@"Aceptar", @"BotonAceptarError") otherButtonTitles: nil];
        [alerta show];
    }
    else 
    {
        [self preservarHora];
        
        
        if(arrayAlarmas)
        {
        }
     
        
        [arrayAlarmas addObject:editingAlarma];
       
        
        [self dismissModalViewControllerAnimated:YES];
    }
}
-(void)cancelar
{

    [self dismissModalViewControllerAnimated:YES];
}


#pragma mark - Acciones de la interfaz

-(IBAction)cambiarEstado:(id)sender
{
   
    UISwitch *interruptor=(UISwitch *)[celdaEstado viewWithTag:1];
    [arrayAlarmas setObservationInfo:[interruptor isOn]];
}

#pragma mark - Delegado de el textview

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];    
    return YES;
}

#pragma mark - Data source de la tabla

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch ([indexPath row]) {
        case 0:
        {
            UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
            
            [[cell textLabel]setText:NSLocalizedString(@"addAlarma", @"celdaEstadoaddAlarmaCell")];
       
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
   
            
            return cell;
        }
            break;
            case 1:
        {
            
            UITableViewCell *cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
            
            if (arrayAlarmas ==nil){
               
                [[cell detailTextLabel]setText:[sonidosVC sonidoElegido]];
            } else {
               
            }
            [[cell textLabel]setText:NSLocalizedString(@"Sonido", @"CeldaSonidos")];
            [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
            
            return cell;
        }
            break;
            case 2:
        {
            
            UILabel *labelEstado=(UILabel *)[celdaEstado viewWithTag:2];
            [labelEstado setText:NSLocalizedString(@"Estado", @"CeldaEstado")];
            
            return celdaEstado;
        }
            
        default:
        {
            return [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
        }
            break;
    }
   
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index
{
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch ([indexPath row]) {
        case 0:
        {
            
            [[self navigationController]pushViewController:editarVC animated:YES];
        }
            break;
        case 1:
        {
          
       
           
            [[self navigationController]pushViewController:sonidosVC animated:YES];
          
            editingAlarma=[sonidosVC editingAlarma];
        }
            break;
        default:
            break;
    }
}

@end
