//
//  AjustesViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "AjustesViewController.h"
#import <AudioToolbox/AudioServices.h>
#import "TimeClockWorldCell.h"
#import "AjustesViewController.h"
#import "FinancesTableViewController.h"
#import "FinancesCell.h"
#import "TimeWorldViewController.h"
#import "Settings.h"

@interface AjustesViewController (){
    NSMutableArray *_objects;
    NSData *pngData;
    NSData *syncResData;
    NSMutableURLRequest *request;
    UIActivityIndicatorView *indicator;
    
#define URL            @"http://bolduoptic.webcindario.com/insertar.php"
#define NO_CONNECTION  @"No Connection"
#define DOCUMENT_DIRECTORY      @"/Documents/"
    
    
    UIRefreshControl *refreshControl;
    
    NSString *fileText;
    NSString *fileTitle;
}

@property (strong, nonatomic) NSDate *detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailLblTimeClockWorld;
- (void)configureView;
@end


@implementation AjustesViewController
{
    NSArray *sonidos;
    NSUInteger indiceSeleccionado;
}
 // SETINGS SOS  //
@synthesize enableCell,enableSwitch,LblEnableSOSOn,LblEnableSOSOFF;

// SETINGS VIBRAR //
@synthesize VibrarCell,VibrarSwitch,LblEnableOnVibrar,LblEnableOFFVibrar;

// SETINGS UPDATES //
@synthesize UpdatesCell,UpdatesSwitch,LblEnableOnUpdates,LblEnableOFFUpdates;

// SETINGS SOUNDS //
@synthesize SoundCell,soundMINLabel,soundMAXLabel,volumeSlider;

// SETINGS LOCATIONS //
@synthesize LocationsCell,LocationsSwitch,LblEnableLocationsON,LblEnableLocationsOFF;

// SETINGS TIME CLOCK WORLD //
@synthesize TimeWordlCell,detailLblTimeClockWorld;


#pragma mark - Segues



- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark iCloud


- (void)viewDidLoad{
    
     [super viewDidLoad];
    
    [enableSwitch setOn:NO];
    [VibrarSwitch setOn:NO];
    [UpdatesSwitch setOn:NO];
    [LocationsSwitch setOn:NO];


    
     // SETINGS SOS //
    LblEnableSOSOn.textColor = [UIColor greenColor];
    LblEnableSOSOFF.textColor = [UIColor redColor];
    
     // SETINGS VIBRAR //
    LblEnableOnVibrar.textColor = [UIColor greenColor];
    LblEnableOFFVibrar.textColor = [UIColor redColor];
    
     // SETINGS UPDATES //
    LblEnableOnUpdates.textColor = [UIColor greenColor];
    LblEnableOFFUpdates.textColor = [UIColor redColor];
    
     // SETINGS SOUNDS //
   // soundMINLabel.textColor = [UIColor grayColor];
    soundMAXLabel.textColor = [UIColor greenColor];

    
    // SETINGS LOCATIONS //
    LblEnableLocationsON.textColor = [UIColor greenColor];
    LblEnableLocationsOFF.textColor = [UIColor redColor];
    
     // SETINGS TIME CLOCK WORLD //
    detailLblTimeClockWorld.textColor = [UIColor greenColor];
    
    

    
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
     AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    

    if([[UIDevice currentDevice].model isEqualToString:@"iPhone"])
    {
        AudioServicesPlaySystemSound (1352);
    }
    else
    {
        
        AudioServicesPlayAlertSound (1105);
    }
    
    [self configureView];
    
}


- (void)vibratePhone;
{
    if([[UIDevice currentDevice].model isEqualToString:@"iPhone"])
    {
        AudioServicesPlaySystemSound (1352);
    }
    else
    {
       
        AudioServicesPlayAlertSound (1105);
    }
}

-(IBAction)BtnSave:(id)sender{
    
    [[NSUserDefaults standardUserDefaults] setBool:TRUE forKey:@"Level"];
    [[NSUserDefaults standardUserDefaults] synchronize];

    NSLog(@"Guardamos los datos...");
    
    NSUserDefaults *datos = [NSUserDefaults standardUserDefaults];
    

    [datos setObject:detailLblTimeClockWorld.text forKey:@"timeClockWordl"];
    
  
    
    [[[UIAlertView alloc] initWithTitle:nil message:@"Saved Tools Clock!" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] show];

  
    
    [indicator stopAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = FALSE;

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions



- (IBAction)ActivarSOS:(id)sender{
    

    if (enableSwitch.on){
             // SETINGS SOS  LblEnableSOSOn,LblEnableSOSOFF;//
        LblEnableSOSOn.textColor = [UIColor greenColor];
        LblEnableSOSOn.text = @"ENABLED";
        
        enableSwitch.enabled = enableSwitch.enabled = YES;
        enableSwitch.alpha = enableSwitch.alpha = .5;
        
        
    }else{
        LblEnableSOSOFF.textColor = [UIColor redColor];
        LblEnableSOSOFF.text = @"DISABLED";
        
        
        enableSwitch.enabled = enableSwitch.enabled = NO;
        enableSwitch.alpha = enableSwitch.alpha = .5;
    }
    [delegateAjuste metodoAjuste];
}



- (IBAction)ActivarVibrar:(id)sender {
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);

    if (VibrarSwitch.on){
        
        LblEnableOnVibrar.textColor = [UIColor greenColor];
        LblEnableOnVibrar.text = @"ENABLED";
        
        VibrarSwitch.enabled = VibrarSwitch.enabled = YES;
        VibrarSwitch.alpha = VibrarSwitch.alpha = .5;
        AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
        if([[UIDevice currentDevice].model isEqualToString:@"iPhone"])
        {
            AudioServicesPlaySystemSound (1352);
        }
        else
        {
            
            AudioServicesPlayAlertSound (1105);
        }
        
        
    }else{
        LblEnableOFFVibrar.textColor = [UIColor redColor];
        LblEnableOFFVibrar.text = @"DISABLED";

        
        VibrarSwitch.enabled = VibrarSwitch.enabled = YES;
        VibrarSwitch.alpha = VibrarSwitch.alpha = .5;
        AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
     
    }
    [delegateAjuste metodoAjuste];
}

- (IBAction)ActivarUpdates:(id)sender{

    if (UpdatesSwitch.on){
        
        LblEnableOnUpdates.textColor = [UIColor greenColor];
        LblEnableOnUpdates.text = @"ENABLED";
        
        UpdatesSwitch.enabled = UpdatesSwitch.enabled = YES;
        UpdatesSwitch.alpha = UpdatesSwitch.alpha = .5;

        
    }else{

        LblEnableOFFUpdates.textColor = [UIColor redColor];
        LblEnableOFFUpdates.text = @"DISABLED";
        
        UpdatesSwitch.enabled = UpdatesSwitch.enabled = NO;
        UpdatesSwitch.alpha = UpdatesSwitch.alpha = .5;
        
        
    }
    [delegateAjuste metodoAjuste];
}

- (IBAction)ActivarLocations:(id)sender{

    if (LocationsSwitch.on){
        
        LblEnableLocationsON.textColor = [UIColor greenColor];
        LblEnableLocationsON.text = @"ENABLED";

        LocationsSwitch.enabled = LocationsSwitch.enabled = YES;
        LocationsSwitch.alpha = LocationsSwitch.alpha = .5;
        
        
        
    }else{
        
        LblEnableLocationsOFF.textColor = [UIColor redColor];
        LblEnableLocationsOFF.text = @"DISABLED";

        
        LocationsSwitch.enabled = LocationsSwitch.enabled = YES;
        LocationsSwitch.alpha = LocationsSwitch.alpha = .5;
        
    }
    [delegateAjuste metodoAjuste];
}



- (IBAction)Volumen:(UISlider *)volumeSlider{

    
   self.soundMAXLabel.text  =  [NSString stringWithFormat:@"%i", self.volumeSlider.value];
}


#pragma mark - Managing the detail item

- (void)setDetailItem:(id)newDetailItem
{
    if (_detailItem != newDetailItem) {
        _detailItem = newDetailItem;
        
        [self configureView];
    }
}

- (void)configureView
{
    
    if (self.detailItem) {
        self.detailLblTimeClockWorld.text = [self.detailItem description];
        
    }
    
  
}



@end
