//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//


#import "TimeWorld.h"

@implementation TimeWorld

- (id)initWithlbltimewordl:(NSString *)albltimewordl
                     lblAM:(NSString *)alblAM
                     lblPM:(NSString *)alblPM
                   Country:(NSString *)aCountry {
    self = [super init];
    
    if (self) {
        self.lbltimewordl = albltimewordl;
        self.lblAM = alblAM;
        self.lblPM = alblPM;
        self.Country = aCountry;
    }
    
    return self;
}




- (id)initWithDictionary:(NSDictionary *)dic {
    self = [self initWithlbltimewordl:@"lbltimewordl" lblAM:@"lblAM" lblPM:@"lblPM" Country:@"Country"];
    return self;
}

- (id)init {
    self = [self initWithlbltimewordl:@"Undifined" lblAM:@"Undifined" lblPM:@"Undifined" Country:@"Undifined"];
    return self;


}

- (NSString *)description {
    return [NSString stringWithFormat:@"%@ : %@",  self.lbltimewordl,self.lblAM,self.lblPM,self.Country, self.description];
}

@end
