//
//  sonidosViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 08/04/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "sonidosViewController.h"
#import "Settings.h"
#import "insist.h"


static Settings*sharedSettings = nil;

@interface sonidosViewController ()

enum
{
    SUNRISE,
    CIVIL,
    NAUTICAL,
    ASTRONOMICAL
};
@end

@implementation sonidosViewController
@synthesize arraySonidos, sonidoElegido, lastIndexPath, editingAlarma;

@synthesize time, vibrate, enabled, dayMask, snoozeMinutes, soundIndex, volume;
@synthesize offset, lat, lon, weather, vampire;

+ (NSString*)archivePath
{
    NSArray*paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    insist (paths && [paths count]);
    return [[paths objectAtIndex:0] stringByAppendingPathComponent:@"SELECT SOUND"];
    
}


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        
        navigationItem=[self navigationItem];
        [navigationItem setTitle:@"Sonidos"];
        
           if(!sonidoElegido)
        {
            sonidoElegido=@"RingRingTecno_Merge";
        }
        
        [[self tableView]setAllowsMultipleSelection:NO];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
  
    arraySonidos=[[NSMutableArray alloc]initWithObjects:@"RingRingTecno_Merge",
                  @"alarm_clock_ringing",
                  @"card_reader_alarm",
                  @"church_bells",
                  @"police",
                  @"baby_crying", nil];

    
    soundStrings =[[NSMutableArray alloc]initWithObjects:@"RingRingTecno_Merge",
                   @"alarm_clock_ringing",
                   @"card_reader_alarm",
                   @"church_bells",
                   @"police",
                   @"baby_crying", nil];
}



-(id)initWithCoder:(NSCoder*)coder
{
    insist (coder);
    self = [super init];
    insist(self);
    
    time = [coder decodeIntForKey:@"time"];
    dayMask = [coder decodeIntForKey:@"dayMask"];
    snoozeMinutes = [coder decodeIntForKey:@"snoozeMinutes"];
    soundIndex = [coder decodeIntForKey:@"soundIndex"];
    volume = [coder decodeFloatForKey:@"volume"];
    vibrate = [coder decodeBoolForKey:@"vibrate"];
    enabled = [coder decodeBoolForKey:@"enabled"];
    offset = [coder decodeIntForKey:@"offset"];
    lat = [coder decodeDoubleForKey:@"lat"];
    lon = [coder decodeDoubleForKey:@"lon"];
    weather = [coder decodeBoolForKey:@"weather"];
    vampire = [coder decodeBoolForKey:@"vampire"];
    return self;
}


-(void)encodeWithCoder:(NSCoder*)coder
{
    insist (coder);
    
    [coder encodeInt:time forKey:@"time"];
    [coder encodeInt:dayMask forKey:@"dayMask"];
    [coder encodeInt:snoozeMinutes forKey:@"snoozeMinutes"];
    [coder encodeInt:soundIndex forKey:@"soundIndex"];
    [coder encodeFloat:volume forKey:@"volume"];
    [coder encodeBool:vibrate forKey:@"vibrate"];
    [coder encodeBool:enabled forKey:@"enabled"];
    [coder encodeInt:offset forKey:@"offset"];
    [coder encodeDouble:lat forKey:@"lat"];
    [coder encodeDouble:lon forKey:@"lon"];
    [coder encodeBool:weather forKey:@"weather"];
    [coder encodeBool:vampire forKey:@"vampire"];
}




- (id) init
{
    self = [super init];
    insist (self);
    
    time = SUNRISE;
    dayMask = 0x7f;
    snoozeMinutes = 1;
    soundIndex = 0;
    volume = 1.0;
    vibrate = NO;
    enabled = NO;
    offset = 0;
    lat = lon = 0;
    weather = YES;
    vampire = NO;
    
    
    
    return self;
}

- (id) copyWithZone:(NSZone*)zone
{
    return self;
}

- (id) copy
{
    return self;
}

- (NSUInteger) isTime
{
    return NSUIntegerMax;
}


- (void) accessibilityIncrement
{
}

- (id) autoContentAccessingProxy
{
    return self;
}

- (int)getTime
{
    return time;
}

-(void)setTime:(int)aTime
{
    insist(time >= 0 && time < 4);
    time = aTime;
}

- (NSArray*)getTimeStrings
{
    return [NSArray arrayWithObjects:vampire ? @"Sunset" : @"Sunrise", @"Civil Twilight", @"Nautical Twilight", @"Astronomical Twilight", nil];
}

-(NSArray*)getSoundStrings
{
    return soundStrings;
}

-(NSURL*)urlForSound:(int)index
{
    return [[NSBundle mainBundle] URLForResource:[sounds objectAtIndex:index] withExtension:@"wav"];
}

-(NSString*)fileNameForSound:(int)index
{
    return [NSString stringWithFormat:@"%@.wav", [sounds objectAtIndex:index]];
}

-(NSString*)snoozeStringForInt:(int)minutes
{
    if (minutes == 1)
        return @"1 Minute";
    else
        return [NSString stringWithFormat:@"%d Minutes", minutes];
}


-(bool)on
{
    return enabled && dayMask;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)viewWillAppear:(BOOL)animated
{
    [[self tableView]reloadData];
}

-(void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"%@", sonidoElegido);
   
    
    [audioPlayer stop];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return [arraySonidos count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(!cell)
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    

    [[cell textLabel]setText:[arraySonidos objectAtIndex:[indexPath row]]];
    
   
    if([[[cell textLabel]text]isEqualToString:sonidoElegido])
    {
        [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        lastIndexPath=indexPath;
    }
    
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{   
      UITableViewCell *cellSeleccionada=(UITableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    
      [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
      UITableViewCell *celdaAntigua=(UITableViewCell *)[tableView cellForRowAtIndexPath:lastIndexPath];
    [celdaAntigua setAccessoryType:UITableViewCellAccessoryNone];
    

    lastIndexPath = indexPath;
    
 
    [cellSeleccionada setAccessoryType:UITableViewCellAccessoryCheckmark];
    
    sonidoElegido=[[cellSeleccionada textLabel]text];
    
    NSString *rutaMusica=[[NSBundle mainBundle]pathForResource:sonidoElegido ofType:@"wav"];
    if(rutaMusica)
    {
        NSURL *urlMusica=[NSURL fileURLWithPath:rutaMusica];
        audioPlayer=[[AVAudioPlayer alloc]initWithContentsOfURL:urlMusica error:nil];
        
        [audioPlayer setDelegate:self];
        [audioPlayer setNumberOfLoops:1];
       
        [audioPlayer play];
    }
}

@end
