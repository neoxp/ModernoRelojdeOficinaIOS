//
//  SOSViewController.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "SOSViewController.h"
#import "RZTelprompt.h"
#import "CustomAnnotation.h"
#import <MapKit/MapKit.h>
#import "CoreLocationController.h"

@interface SOSViewController ()

- (IBAction)callEmergencies:(id)sender;

@end

@implementation SOSViewController

@synthesize LblLatitud,LbLong,ConectingView;

@synthesize Localizacion;
@synthesize toolBar;



-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *crnLoc = [locations lastObject];
    
    
    self.LblLatitud.text = [NSString stringWithFormat:@"Your Latitud:%.8f",crnLoc.coordinate.latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Your Longitud: %.8f",crnLoc.coordinate.longitude];
    
    
}

- (void)update:(CLLocation *)location {
    self.LblLatitud.text= [NSString stringWithFormat:@"Your Latitud: %f", [location coordinate].latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Your Longitud: %f", [location coordinate].longitude];
}

- (void)locationError:(NSError *)error {
    self.LblLatitud.text = [error description];
    self.LbLong.text = nil;
}




-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{

    NSLog(@"Error: %@",error.description);
}



- (void)viewDidLoad
{
 
    [super viewDidLoad];
    
    
    Localizacion.showsUserLocation = YES;

    Localizacion.delegate = self;
    
    [super viewDidLoad];
    locManager = [[CLLocationManager alloc]init];
    locManager.delegate = self.Localizacion;
    locManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    [locManager startUpdatingLocation];
    
    [self.Localizacion showsPointsOfInterest];
    
    self.Localizacion.mapType = MKMapTypeHybrid;
    
    [self.Localizacion setZoomEnabled:YES];
    
    
    self.Localizacion.showsUserLocation = YES;
    
    self.locationController = [[CoreLocationController alloc] init];
    self.locationController.delegate = self;
    [self.locationController.locationManager startUpdatingLocation];
    
    CLLocationCoordinate2D coordenadas = CLLocationCoordinate2DMake(40.8124466, -0.5214339000000336);
    
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(coordenadas, 100, 100);
    
    [self.Localizacion setShowsUserLocation:YES];
     [self.Localizacion setShowsPointsOfInterest:YES];
    
}

-(void) mapView:(MKMapView *)mapViewdidUpdateUserLocation:(MKUserLocation *)userLocation{
    
    
    NSLog(@"Nueva localización: %@", [userLocation.location description]);
    
}

- (void)zoomIn: (id)sender
{
    MKUserLocation *userLocation = Localizacion.userLocation;
    MKCoordinateRegion region =
    MKCoordinateRegionMakeWithDistance (
                                        userLocation.location.coordinate, 15, 15);
    
    self.LblLatitud.text = [NSString stringWithFormat:@"Your Latitud:%.8f",userLocation.coordinate.latitude];
    self.LbLong.text = [NSString stringWithFormat:@"Your Longitud: %.8f",userLocation.coordinate.longitude];
    [Localizacion setRegion:region animated:YES];
    [self.Localizacion showsUserLocation];
    
    [self.Localizacion showsPointsOfInterest];
    
    [self.Localizacion setZoomEnabled:YES];
}



- (IBAction)callEmergencies:(id)sender
{
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"tel:112",self.LblCallEmergecies.text]];
    [[UIApplication sharedApplication] openURL:url];

    [RZTelprompt callWithString:self.LblCallEmergecies.text];
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if(self.LblCallEmergecies.isFirstResponder){
        [self.LblCallEmergecies resignFirstResponder];
    }
}
@end
