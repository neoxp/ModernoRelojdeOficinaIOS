//
//  YahooWeather.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HTTPFetcher.h"

@interface YahooWeather : NSObject <HTTPFetcherDelegate>
{
  @private
  id delegate;
  BOOL gettingWoeid;
  HTTPFetcher*fetcher;
}

-(id)initWithYahooWeatherDelegate:(id)aDelegate;
-(void)goWithLatitude:(double)lat longitude:(double)lon;

@end




@protocol YahooWeatherDelegate <NSObject>
@required
- (void)weather:(YahooWeather*)weather gotWeather:(NSString*)string;
@end
