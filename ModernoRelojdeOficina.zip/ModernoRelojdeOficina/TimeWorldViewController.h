//
//  TimeWorldViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <MapKit/MapKit.h>
#import "TimeWorld.h"


@interface TimeWorldViewController : UITableViewController<MKMapViewDelegate>{
    
    BOOL _doneInitialZoom;
    MKMapView *mapView;
}

@property (nonatomic, retain) IBOutlet UIBarButtonItem *loadClockWordlTime;
@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic) TimeWorld *ListaTurismo;
@property (strong, nonatomic) NSTimeZone *detailItem;
@property (strong, nonatomic) TimeWorldViewController *detailViewController;
@end


