//
//  sonidosViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 08/04/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "Alarma.h"
#import <UIKit/UIKit.h>
#import "Settings.h"

@interface sonidosViewController : UITableViewController<AVAudioPlayerDelegate>
{
    NSMutableArray *arraySonidos;
    UINavigationItem *navigationItem;
    
    NSString *sonidoElegido;
    
    NSIndexPath *lastIndexPath;
    
    AVAudioPlayer *audioPlayer;
    
    Alarma *editingAlarma;
    
    Settings*settings;
    



@private
    NSArray*sounds;
    NSArray*soundStrings;
}

@property (nonatomic, assign) int time;
@property (nonatomic, assign) BOOL vibrate;
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic, assign) float volume;
@property (nonatomic, assign) float soundIndex;
@property (nonatomic, assign) int snoozeMinutes;
@property (nonatomic, assign) int dayMask;
@property (nonatomic, assign) int offset;
@property (nonatomic, assign) double lat;
@property (nonatomic, assign) double lon;
@property (nonatomic, assign) BOOL weather;
@property (nonatomic, assign) BOOL vampire;

@property (nonatomic) Alarma *editingAlarma;
@property (nonatomic) NSIndexPath *lastIndexPath;
@property (nonatomic) NSMutableArray *arraySonidos;
@property (nonatomic) NSString *sonidoElegido;

@property (strong, nonatomic) NSDate *detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

+(Settings*)sharedSettings;
-(void)archive;
-(NSArray*)getSoundStrings;
-(NSArray*)getTimeStrings;
-(NSString*)snoozeStringForInt:(int)minutes;
-(NSURL*)urlForSound:(int)index;
-(NSString*)fileNameForSound:(int)index;

-(bool)on;
@end
