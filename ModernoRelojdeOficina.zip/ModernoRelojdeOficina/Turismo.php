<?php

    $server = "mysql.webcindario.com";
    $user = "lugaresdeinteres";
    $pass = "admin1234";
    $bd = "lugaresdeinteres";
    
    
    $id = $_GET["id"];
    $Name = $_GET["Name"];
    $Gastronomi = $_GET["Gastronomi"];
    $Ranking = $_GET["Ranking"];
    $location = $_GET["location"];
    $center_lat = $_GET["lat"];
    $center_lng = $_GET["lng"];
    $radius = $_GET["radius"];
    
    $dom = new DOMDocument("1.0");
    $node = $dom->createElement("lugares");
    $parnode = $dom->appendChild($node);
    
    $connection=mysql_connect ($server, $user, $pass);
    if (!$connection) {
        die("Not connected : " . mysql_error());
    }
    
    $db_selected = mysql_select_db($bd, $connection);
    if (!$db_selected) {
        die ("Can\'t use db : " . mysql_error());
    }
    
    
    
    
    $query = sprintf("SELECT `id`, `Name`, `Gastronomi`, `Ranking`, `location`, lat, lng, ( 3959 * acos( cos( radians('%s') ) * cos( radians( lat ) ) * cos( radians( lng ) - radians('%s') ) + sin( radians('%s') ) * sin( radians( lat ) ) ) ) AS distance FROM lugares HAVING distance < '%s' ORDER BY distance LIMIT 0 , 20",
                     mysql_real_escape_string($id),
                     mysql_real_escape_string($Name),
                     mysql_real_escape_string($Gastronomi),
                     mysql_real_escape_string($Ranking),
                     mysql_real_escape_string($location),
                     mysql_real_escape_string($center_lat),
                     mysql_real_escape_string($center_lng),
                     mysql_real_escape_string($center_lat),
                     mysql_real_escape_string($radius));
    $result = mysql_query($query);
    
    $result = mysql_query($query);
    if (!$result) {
        die("Invalid query: " . mysql_error());
    }
    
    header("Content-type: text/json");
    
    while ($row = @mysql_fetch_assoc($result)){
        $node = $dom->createElement("lugares");
        $newnode = $parnode->appendChild($node);
        $newnode->setAttribute("id", $row['id']);
        $newnode->setAttribute("Name", $row['Name']);
        $newnode->setAttribute("Gastronomi", $row['Gastronomi']);
        $newnode->setAttribute("Ranking", $row['Ranking']);
        $newnode->setAttribute("location", $row['location']);
        $newnode->setAttribute("lat", $row['lat']);
        $newnode->setAttribute("lng", $row['lng']);
        $newnode->setAttribute("distance", $row['distance']);
    }
    
    echo $dom->saveXML();
    ?>
