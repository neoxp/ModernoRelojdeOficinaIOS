//
//  AppDelegate.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

