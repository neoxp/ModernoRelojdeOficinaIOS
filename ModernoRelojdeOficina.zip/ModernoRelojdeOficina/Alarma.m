//
//  Alarma.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//



#import <AudioToolbox/AudioServices.h>
#import "Alarma.h"
#import "Settings.h"

#import "insist.h"


void soundCompletionProc(SystemSoundID  ssID,void*clientData);


@implementation Alarma

-(id)init
{
    self = [super init];
    insist (self);
    Sonando = NO;
    return self;
}


-(void)Sonar
{
    
    if (Sonando) return;
    
    Settings*settings = [Settings sharedSettings];
    
    
    if (settings.vibrar)
    {
        AudioServicesPlaySystemSound (kSystemSoundID_Vibrate);
        AudioServicesAddSystemSoundCompletion (kSystemSoundID_Vibrate, 0, 0, soundCompletionProc, CFBridgingRetain(self));
    }
    else
    {
        
        
        NSURL*url = [settings urlForSonidos:[settings sonidoIndex]];
        insist (url);
        
        [avPlayer autoContentAccessingProxy];
        avPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        if (!avPlayer) return;
        insist (avPlayer);
        
        avPlayer.volume = settings.volumen;
        avPlayer.numberOfLoops = -1;
        [avPlayer play];
    }
    Sonando = YES;
}


-(void)Parar
{
    
    if (avPlayer)
    {
        [avPlayer stop];
        [avPlayer autoContentAccessingProxy];
        avPlayer = nil;
    }
    
    
    Sonando = NO;
}


-(void)soundCompletion: (SystemSoundID) ssID
{
    if (Sonando)
        AudioServicesPlaySystemSound (ssID);
    else
        AudioServicesRemoveSystemSoundCompletion (ssID);
}


void soundCompletionProc(SystemSoundID ssID, void*clientData)
{
    insist (clientData);
    Alarma*alarma = (Alarma*)CFBridgingRelease(clientData);
    [alarma soundCompletion:ssID];
}

@end