//
//  Settings.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import "Settings.h"
#import "insist.h"

static Settings*sharedSettings = nil;
enum
{
  SUNRISE,
  CIVIL,
  NAUTICAL,
  ASTRONOMICAL
};


@implementation Settings

@synthesize hora, vibrar, activado, diaMascara, DespertarseMinutes, sonidoIndex, volumen;
@synthesize offset, latitud, longitud, Clima, modo , ActivarClimaImagen;


+ (NSString*)archivePath
{
  NSArray*paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
  insist (paths && [paths count]);
  return [[paths objectAtIndex:0] stringByAppendingPathComponent:@"Herramientas"];

}


- (void)initTransient
{


    sonido =[[NSMutableArray alloc]initWithObjects:@"RingRingTecno_Merge",
                  @"alarm_clock_ringing",
                  @"card_reader_alarm",
                  @"church_bells",
                  @"police",
                  @"baby_crying", nil];
    
    
    sonidoStrings =[[NSMutableArray alloc]initWithObjects:@"RingRingTecno_Merge",
                   @"alarm_clock_ringing",
                   @"card_reader_alarm",
                   @"church_bells",
                   @"police",
                   @"baby_crying", nil];
}



+(Settings*)sharedSettings
{
  if (sharedSettings == nil)
  {

    NSFileManager*fileManager = [NSFileManager defaultManager];
    insist (fileManager);

    if ([fileManager fileExistsAtPath:[Settings archivePath]])
    {
      sharedSettings = [NSKeyedUnarchiver unarchiveObjectWithFile:[Settings archivePath]];
      [sharedSettings initTransient];
      return sharedSettings;
    }


    sharedSettings = [[super allocWithZone:NULL] init];
  }
  return sharedSettings;
}


- (void)archive
{
  [NSKeyedArchiver archiveRootObject:self toFile:[Settings archivePath]];
}
-(id)initWithCoder:(NSCoder*)coder
{
  insist (coder);
  self = [super init];
  insist(self);
 
    
  hora = [coder decodeIntForKey:@"hora"];
  diaMascara = [coder decodeIntForKey:@"diaMascara"];
  DespertarseMinutes = [coder decodeIntForKey:@"DespertarseMinutes"];
  sonidoIndex = [coder decodeIntForKey:@"sonidoIndex"];
  volumen = [coder decodeFloatForKey:@"volumen"];
  vibrar = [coder decodeBoolForKey:@"vibrar"];
  activado = [coder decodeBoolForKey:@"activado"];
  offset = [coder decodeIntForKey:@"offset"];
  latitud = [coder decodeDoubleForKey:@"latitud"];
  longitud = [coder decodeDoubleForKey:@"longitud"];
  Clima = [coder decodeBoolForKey:@"Clima"];
  modo = [coder decodeBoolForKey:@"modo"];
  ActivarClimaImagen = [coder decodeBoolForKey:@"ActivarClimaImagen"];
  return self;
}


-(void)encodeWithCoder:(NSCoder*)coder
{  
  insist (coder);

    
  
  [coder encodeInt:hora forKey:@"hora"];
  [coder encodeInt:diaMascara forKey:@"diaMascara"];
  [coder encodeInt:DespertarseMinutes forKey:@"DespertarseMinutes"];
  [coder encodeInt:sonidoIndex forKey:@"sonidoIndex"];
  [coder encodeFloat:volumen forKey:@"volumen"];
  [coder encodeBool:vibrar forKey:@"vibrar"];
  [coder encodeBool:activado forKey:@"activado"];
  [coder encodeInt:offset forKey:@"offset"];
  [coder encodeDouble:latitud forKey:@"latitud"];
  [coder encodeDouble:longitud forKey:@"longitud"];
  [coder encodeBool:Clima forKey:@"Clima"];
  [coder encodeBool:ActivarClimaImagen forKey:@"ActivarClimaImagen"];
  [coder encodeBool:modo forKey:@"modo"];
}




- (id) init
{
  self = [super init];
  insist (self);
    

  hora = SUNRISE;
  diaMascara = 0x7f;
  DespertarseMinutes = 3;
  sonidoIndex = 0;
  volumen = 3.0;
  vibrar = YES;
  activado = YES;
  offset = 0;
  latitud = longitud = 0;
  Clima = YES;
  ActivarClimaImagen = YES;
  modo = NO;


  [self initTransient];
  
  return self;
}

- (id) copyWithZone:(NSZone*)zone
{
  return self;
}

- (id) copy
{
  return self;
}

- (NSUInteger) isHora
{
  return NSUIntegerMax;
}


- (void) accessibilityIncrement
{
}

- (id) autoContentAccessingProxy
{
  return self;
}

- (int)getHora
{
  return hora;
}

-(void)setTime:(int)aHora
{
  insist(hora >= 0 && hora < 4);
  hora = aHora;
}

- (NSArray*)getWeeeksDaysStrings
{
  return [NSArray arrayWithObjects:modo ? @"LUN" : @"MAR", @"MIE", @"JUE", @"VIER",@"SAB",@"DOM", nil];
}

-(NSArray*)getSonidoStrings
{
  return sonidoStrings;
}

-(NSURL*)urlForSonidos:(int)index;
{
  return [[NSBundle mainBundle] URLForResource:[sonido objectAtIndex:index] withExtension:@"wav"];
}

-(NSString*)fileNameForSonido:(int)index;
{
  return [NSString stringWithFormat:@"%@.wav", [sonido objectAtIndex:index]];
}



-(NSArray*)getActivarClimaImagenStrings
{
    return ActivarClimaImagenStrings;
}



-(NSString*)DespertarseStringForInt:(int)minutes
{
  if (minutes == 1)
    return @"1 Minuto";
  else
    return [NSString stringWithFormat:@"%d Minutos", minutes];
}


-(bool)on
{
  return activado && ActivarClimaImagen &&diaMascara;
}
@end
