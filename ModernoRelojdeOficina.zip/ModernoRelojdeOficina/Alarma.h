//
//  Alarma.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface Alarma : NSObject
{
    BOOL Sonando;
    AVAudioPlayer*avPlayer;
}

-(void)Sonar;
-(void)Parar;

@end
