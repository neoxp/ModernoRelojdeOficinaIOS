
<?php

function Conectarse()
{
    if (!($link=mysql_connect("mysql.webcindario.com","lugaresdeinteres","admin1234")))
    {
        echo "Error conectando a la base de datos.";
        exit();
    }
    if (!mysql_select_db("lugaresdeinteres",$link))
    {
        echo "Error seleccionando la base de datos.";
        exit();
    }
    return $link;
}

$link=Conectarse();
echo "Conexión con la base de datos conseguida.<br>";

mysql_close($link);
?>
