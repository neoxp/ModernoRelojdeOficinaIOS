//
//  Turismo.h
//  ProvaEmiliMarques
//
//  Created by Hackermaster on 28/06/16.
//  Copyright (c) 2016 Emili Marques. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Finances : NSObject

@property (strong, nonatomic)NSString *name;
@property (strong, nonatomic)NSString *moneyUp;
@property (strong, nonatomic)NSString *moneyDown;


@property (strong, nonatomic)NSString *Ranking;
@property (strong, nonatomic)NSString *Cordenadas;

- (id)initWithName:(NSString *)aName
             moneyUp:(NSString *)amoneyUp
           moneyDown:(NSString *)amoneyDown;



- (id)initWithDictionary:(NSDictionary *)dic;

@end
