//
//  FinancesTableViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <MapKit/MapKit.h>
#import "Finances.h"

@class FinancesTableViewController;

@interface FinancesTableViewController : UITableViewController<MKMapViewDelegate>{
    
    BOOL _doneInitialZoom;
    MKMapView *mapView;
}

@property (nonatomic, retain) IBOutlet UIBarButtonItem *loadFinances;
@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic) Finances *ListaTurismo;
@property (strong, nonatomic) NSNumber *detailItem;
@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;

@property (strong, nonatomic) FinancesTableViewController *detailViewController;
@end

