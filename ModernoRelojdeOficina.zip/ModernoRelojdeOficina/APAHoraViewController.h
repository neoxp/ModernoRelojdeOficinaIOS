//
//  APAHoraViewController.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster on 25/06/14.
//  Copyright (c) 2014 HackerMaster. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "Settings.h"
#import "BEMAnalogClockView.h"
#import "insist.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "RZTelprompt.h"
#import "CustomAnnotation.h"
#import "HTTPFetcher.h"
#import "YahooWeather.h"
#import "XMLReader.h"
#import "insist.h"

#import <MapKit/MapKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MediaToolbox/MediaToolbox.h>
#import "CoreLocationController.h"

#import "MapOverlayView.h"
#import "MapOverlay.h"


@interface APAHoraViewController : UIViewController<MKMapViewDelegate,MKLocalSearchCompleterDelegate,HTTPFetcherDelegate,CoreLocationControllerDelegate,MKMapViewDelegate,MKLocalSearchCompleterDelegate,CoreLocationControllerDelegate>{
    
    MKMapView *mapView;
    UIToolbar *toolBar;
    MKPointAnnotation *annotationPoint;
    MKMapPoint *point;
    CLLocationManager *locManager;




    id delegate;
    BOOL gettingWoeid;
    HTTPFetcher*fetcher;

    NSMutableArray *modo;
    
 
    NSDateComponents*currentComponents;
    NSDate*currentDate;
    NSDateFormatter*dateFormatter;
    NSArray*days;
}
@property(nonatomic) NSCalendarIdentifier modo;

-(id)initWithYahooWeatherDelegate:(id)aDelegate;
-(void)goWithLatitude:(double)lat longitude:(double)lon;
@property (nonatomic, retain) CoreLocationController *locationController;

-(bool)on;
-(void)setDate:(NSDate*)date;
-(void)setOnHidden:(BOOL)hidden;

@end


@protocol YahooWeatherDelegate <NSObject>
@required
- (void)weather:(YahooWeather*)weather gotWeather:(NSString*)string;
@end
