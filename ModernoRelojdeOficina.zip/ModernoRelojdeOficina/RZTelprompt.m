//
//  RZTelprompt.m
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 16/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//

#import "RZTelprompt.h"

@implementation RZTelprompt

+ (void)callWithString:(NSString *)phoneString
{
    [self callWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:112",phoneString]]];
}

+ (void)callWithURL:(NSURL *)url
{
    static UIWebView *webView = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        webView = [[UIWebView alloc] init];
    });
    
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}

@end
