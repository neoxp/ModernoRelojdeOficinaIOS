//
//  MapOverlayView.h
//  ModernoRelojdeOficina
//
//  Created by HackerMaster   on 26/5/17.
//  Copyright © 2017 appdevelpment. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface MapOverlayView : MKOverlayView {
    
}

@end
